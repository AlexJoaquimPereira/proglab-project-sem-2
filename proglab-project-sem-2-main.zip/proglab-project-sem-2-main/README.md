# Experiment 12 of my Programming Laboratory course
Write a C program to create a employee management system. Program should facilitate the end user to create a separate file for each employee with employee name as the file name. Employee record details should be :ename, eage, designation. Program must dynamically reserve the memory for each employee record created. Provide a menu driven o/p with following options for the program:                                                                                      
1. To enter employee details and display separately each file as o/p                                                                          
2. To edit eage and also display the updated content
3. To append address to a employee file & display appended content on screen
